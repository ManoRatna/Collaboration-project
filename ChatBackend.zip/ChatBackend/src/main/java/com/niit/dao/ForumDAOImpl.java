package com.niit.dao;

import java.util.List;

import com.niit.model.Forum;
import com.niit.model.ForumComment;

public class ForumDAOImpl implements ForumDAO{

	public boolean addForum(Forum forum) {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean deleteForum(int forumId) {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean updateForum(Forum forum) {
		// TODO Auto-generated method stub
		return false;
	}

	public List<Forum> listForums(String forumname) {
		// TODO Auto-generated method stub
		return null;
	}

	public Forum getForum(int forumId) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Forum> listAllForums() {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean addForumComment(ForumComment forumComment) {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean deleteForumComment(ForumComment forumComment) {
		// TODO Auto-generated method stub
		return false;
	}

	public ForumComment getBlogcomment(int commentId) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<ForumComment> listForumComments(int forumId) {
		// TODO Auto-generated method stub
		return null;
	}

}
