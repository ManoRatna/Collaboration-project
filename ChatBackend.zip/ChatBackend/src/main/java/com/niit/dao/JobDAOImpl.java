package com.niit.dao;

import java.util.List;

import com.niit.model.Job;

public class JobDAOImpl implements JobDAO{

	public boolean addJob(Job job) {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean deleteJob(Job job) {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean updateJob(Job job) {
		// TODO Auto-generated method stub
		return false;
	}

	public List<Job> listAllJobs() {
		// TODO Auto-generated method stub
		return null;
	}

}
