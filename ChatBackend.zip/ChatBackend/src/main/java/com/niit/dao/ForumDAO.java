package com.niit.dao;

import java.util.List;

import com.niit.model.Forum;
import com.niit.model.ForumComment;

public interface ForumDAO {

	public boolean addForum(Forum forum);
	public boolean deleteForum(int forumId);
	public boolean updateForum(Forum forum);
	public List<Forum> listForums(String forumname);
	//public boolean approveForum(Blog blog);
	//public boolean reject(Blog blog);
	public Forum getForum(int forumId);
	public List<Forum> listAllForums();
	//public boolean incrementLike(Blog blog);
	
	public boolean addForumComment(ForumComment forumComment);
	public boolean deleteForumComment(ForumComment forumComment);
	public ForumComment getBlogcomment(int commentId);
	public List<ForumComment> listForumComments(int forumId);
}
